//header files
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched/signal.h>
#include <linux/init.h>
#include <linux/pid.h>
#include <linux/moduleparam.h>
#include <linux/sched.h>
//
static int target_pid = 1; // Default to 1 (init process)
module_param(target_pid, int, 0644);// passes a pid as a parameter and sets the permissions so it can be modified
MODULE_PARM_DESC(target_pid, "Process ID to lookup");

//changes the states of the processes for easier reading and printing to console
static char *get_task_state(long state) {
    switch (state) {
        case TASK_RUNNING: return "TASK_RUNNING";
        case TASK_INTERRUPTIBLE: return "TASK_INTERRUPTIBLE";
        case TASK_UNINTERRUPTIBLE: return "TASK_UNINTERRUPTIBLE";
        case __TASK_STOPPED: return "TASK_STOPPED";
        case __TASK_TRACED: return "TASK_TRACED";
        default: return "UNKNOWN_STATE";
    }
}

//returns a pointer to the task struct which has the info about the process
/*static int __init print_other_init(void) {
    struct task_struct *task;

    printk(KERN_INFO "print_other: Looking up process with PID %d\n", target_pid);

    task = pid_task(find_vpid(pid), PIDTYPE_PID);
    if (!task) {
        printk(KERN_ERR "print_other: Could not find process with PID %d\n", target_pid);
        return -ESRCH;// no process exists with that ID
    }

    // Traverse the process hierarchy all the way to init 
    while (task) {
        printk(KERN_INFO "Process: %s (PID: %d, State: %s)\n",
               task->comm, task->pid, get_task_state(task->__state));

        if (task->pid == 1) // Stop at init process so we dont infinite loop 
            break;

        task = task->parent; // Move to the parent process and do next loop
    }

    return 0;
}*/
static int __init print_other_init(void) {
    struct task_struct *task;

    printk(KERN_INFO "print_other: Looking up process with PID %d\n", target_pid);

    task = pid_task(find_vpid(target_pid), PIDTYPE_PID);
    if (!task) {
        printk(KERN_ERR "print_other: Could not find process with PID %d\n", target_pid);
        return -ESRCH;// no process exists with that ID
    }

    // Traverse the process hierarchy all the way to init
    while (task) {
        printk(KERN_INFO "Process: %s (PID: %d, State: %s)\n",
               task->comm, task->pid, get_task_state(task->__state));

        if (task->pid == 1) // Stop at init process so we dont infinite loop
            break;

        task = task->parent; // Move to the parent process and do next loop
    }

    return 0;
}

// remove the module and print a message

static void __exit print_other_exit(void) {
    printk(KERN_INFO "print_other: Module unloaded.\n");
}
// register the init and exit functions
module_init(print_other_init);
module_exit(print_other_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Kernel module to print process hierarchy for a given PID.");

