How to run the program:
1. Run make so that the print_other.ko can be generated.
2. Run pgrep bash to get a running pid
3. run "sudo insmod print_other.ko your_pid"
4. run "sudo dmesg -T | tail -20" to see logs
5. remove the module by running "sudo rmmod print_other"
